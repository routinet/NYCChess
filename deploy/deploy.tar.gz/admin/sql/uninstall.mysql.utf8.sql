DROP TABLE IF EXISTS `#__nycc_locations`;
DROP TABLE IF EXISTS `#__nycc_rates`;
DROP TABLE IF EXISTS `#__nycc_events`;
DROP TABLE IF EXISTS `#__nycc_venues`;
DROP TABLE IF EXISTS `#__nycc_venue_rates`;
