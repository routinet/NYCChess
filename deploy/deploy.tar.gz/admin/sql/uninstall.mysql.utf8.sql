DROP TABLE IF EXISTS `#__nycc_locations`;
