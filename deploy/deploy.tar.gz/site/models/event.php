<?php
/**
 * @package     NYCCEvents
 * @subpackage  com_nyccevents
 *
 * @copyright   Copyright (C) 2016 Steve Binkowski.  All Rights Reserved.
 * @license     Commercial License Only
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Event Model
 *
 * @since  0.0.1
 */
class NyccEventsModelEvent extends NyccEventsModelBase {

  protected $_lookups = array(
    'location' => array('field'=>'main_location', 'table'=>'locations', 'lookup'=>'name'),
    );

  /**
   * Returns true if this event has venues loaded.
   * @return bool
   *
   * @since 0.0.1
   */
  public function hasVenues() {
    return (isset($this->venues) && is_array($this->venues) && count($this->venues));
  }

  public function getVenueProperties($property, $format = 'U') {
    $ret = array();
    if ($this->hasVenues()) {
      foreach ($this->venues as $key=>$venue) {
        switch ($property) {
          case 'id':
          case 'display_name':
          case 'location_id':
          case 'location_name':
            $ret[] = $venue->{$property};
            break;
          case 'event_date':
            $ret[] = date($format, $venue->event_date);
            break;
        }
      }
    }
    return $ret;
  }

  /**
   * Returns an array of all dates available in loaded venues.  If no venues
   * are available (none assigned or not loaded), an empty array is returned.
   *
   * @param string $format
   *    A format string as in date().  Defaults to 'U' (unix timestamp)
   *
   * @return array
   *
   * @since 0.0.1
   */
  public function getVenueDates($format = 'U') {
    return $this->getVenueProperties('event_date', $format);
  }

  public function getVenueLocations($getIds = false) {
    return $this->getVenueProperties('location_' . ($getIds ? 'id' : 'name'));
  }
}